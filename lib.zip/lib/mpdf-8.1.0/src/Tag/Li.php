<?php

namespace Mpdf\Tag;

class Li extends BlockTag
{


}
